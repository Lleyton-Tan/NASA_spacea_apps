extends Node2D
## Mars Base Survival. World is 320x240 px drawn at 3x; UI sits on top at native resolution.

const TextBoxScript := preload("res://scripts/text_box.gd")

# ===================== TEXT PLACEHOLDERS: fill these in =====================
# TUTORIAL DIALOGUE: one string per box. Teach: WASD gathering, the 15s timer, events, repairs (E), End Period, win/lose.
const TUTORIAL_LINES := ["Your mission has gone awry, and your base is shutting down in 15 seconds. Fortunately, the bunker is self-sufficient.", 
						 "Take all you can down there because the base you once knew is now chock-full of broken systems.", 
						 "Sacrifice your scarce resources to get them up and running one by one, or be prepared to join Perseverance as an exploration mission of the past.",
						 "Use your W, A, S, D keys to move around and pick up the resources!", 
						 "Remember to manage each resource carefully to fix your base and call for help. Good Luck, Junior Astronaut"]
# DIALOGUE: shown when the 15s gathering ends and the astronaut is in the bunker.
const BUNKER_TEXT := "Nice work! Now, each period will show show a text event at the start, make the choice that will help you gain and manintain resources to fix the systems!"
# DIALOGUE: shown after each repair, one per component id.
const REPAIR_TEXT := {"solar": "DID YOU KNOW: Since Mars is 1.5 AU away from the Sun, its peak solar power is less than Earth's, and it varies depending on the seasons!", 
					  "shield": "DID YOU KNOW: The Mars surface has 0.65 millisieverts of radiation per day. For reference, getting a chest X-Ray only exposes you to 0.04! So you better keep that suit on!", 
					  "food": "DID YOU KNOW: Nasa's findings of growing crops in space point to differnet light specturms and gravity having a role in which plants get to grow! These include lettuce, Chinese cabbage, and tomatoes!", 
					  "humid": "DID YOU KNOW: Martian dust storms can reach up to 60 mph, and global and planet-encircling storms happen once every three martian years. Stay safe, Junior Astronaut!", 
					  "antenna": "DID YOU KNOW: NASA found that, on average, an 80+ kg human would need 0.89 kg of oxygen, 2.79 kg of water, and 2.39 kg of food! Good thing you're headed home, Junior Astronaut!"}
# DIALOGUE: game over message (then back to main menu) and win / congratulation message.
const GAME_OVER_TEXT := "GAME OVER! Nice try, Junior Astronaut!"
const WIN_TEXT := "YOU WIN! Great job, Junior Astronaut!"
# EVENT STORY TEXT: fill each event's "desc" in EVENTS below.
# ============================================================================

const GATHER_TIME := 15.0
const PASSIVE_EVERY := 2          # passive components produce every N periods
const SPEED := 70.0               # world px / second
const REACH := 20.0
const DOOR_Y := 100.0             # walking above this line inside the gate = entering the bunker
const WALLS := [Rect2(0, 92, 144, 12), Rect2(176, 92, 144, 12), Rect2(148, 0, 25, 46)]   # fence + bunker body

# fx keys: f=food w=water e=energy i=suit integrity. "lose": true = instant game over.
const EVENTS := [
	{"desc": "Water to food", "a": {"label": "Consume 3 water, create 2 food", "fx": {"w": -3, "f": 2}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "Water to energy", "a": {"label": "Consume 2 water, create 2 energy", "fx": {"w": -2, "e": 2}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "Water to integrity", "a": {"label": "Consume 2 water, +1 suit integrity", "fx": {"w": -2, "i": 1}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "Food to water", "a": {"label": "Consume 2 food, create 2 water", "fx": {"f": -2, "w": 2}}, "b": {"label": "Don't use food", "fx": {}}},
	{"desc": "Food to energy", "a": {"label": "Consume 2 food, create 2 energy", "fx": {"f": -2, "e": 2}}, "b": {"label": "Don't use food", "fx": {}}},
	{"desc": "Food to integrity", "a": {"label": "Consume 1 food, +1 suit integrity", "fx": {"f": -1, "i": 1}}, "b": {"label": "Don't use the food", "fx": {}}},
	{"desc": "Energy to water", "a": {"label": "Spend 2 energy, create 2 water", "fx": {"e": -2, "w": 2}}, "b": {"label": "Don't spend energy", "fx": {}}},
	{"desc": "Energy to food", "a": {"label": "Spend 2 energy, create 2 food", "fx": {"e": -2, "f": 2}}, "b": {"label": "Don't spend energy", "fx": {}}},
	{"desc": "Integrity to food", "a": {"label": "Spend 1 integrity, create 2 food", "fx": {"i": -1, "f": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	{"desc": "Integrity to water", "a": {"label": "Spend 1 integrity, create 2 water", "fx": {"i": -1, "w": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	{"desc": "Integrity to energy", "a": {"label": "Spend 1 integrity, create 2 energy", "fx": {"i": -1, "e": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	# solar flare
	{"desc": "ALERT: Solar Flare detected!", "a": {"label": "Hide under your resources (-2 food, -2 water)", "fx": {"f": -2, "w": -2}}, "b": {"label": "Power the radiation shield (-1 energy, -1 integrity)", "fx": {"e": -1, "i": -1}}},
	# dust storm
	{"desc": "ALERT: Dust Storm detected!", "a": {"label": "Exit to strengthen the bunker (-1 water, -1 food)", "fx": {"w": -1, "f": -1}}, "b": {"label": "Stay inside (-2 energy cells)", "fx": {"e": -2}}},
	# radiation spike
	{"desc": "ALERT: Radiation Spike detected!", "a": {"label": "Sleep in your suit (-1 integrity)", "fx": {"i": -1}}, "b": {"label": "Don't", "fx": {}, "lose": true}},
	# cold night
	{"desc": "ALERT: It's a Cold-Night!", "a": {"label": "Turn on the heater (-1 energy)", "fx": {"e": -1}}, "b": {"label": "Don't (-1 water)", "fx": {"w": -1}}},
]

# Stations (world px, top-left of 16x16 sprite). tex = [file, region in the sheet].
const COMPONENTS := [
	{"id": "solar", "name": "Solar panels", "pos": Vector2(24, 64), "cost": {"f": 1, "w": 1, "e": 1, "i": 1}, "passive": {"e": 1}, "tex": ["furniture", Rect2(32, 0, 16, 16)]},
	{"id": "shield", "name": "Radiation shielding", "pos": Vector2(72, 64), "cost": {"f": 1, "w": 1, "e": 2}, "perm": true, "tex": ["chest", Rect2(16, 16, 16, 16)]},
	{"id": "food", "name": "Food generator", "pos": Vector2(216, 64), "cost": {"f": 2, "w": 1, "e": 2}, "passive": {"f": 1}, "tex": ["furniture", Rect2(48, 32, 16, 16)]},
	{"id": "humid", "name": "Humidifier", "pos": Vector2(264, 64), "cost": {"f": 2, "w": 2, "e": 2}, "passive": {"w": 1}, "tex": ["furniture", Rect2(16, 0, 16, 16)]},
	{"id": "antenna", "name": "Antenna (final)", "pos": Vector2(144, 66), "cost": {"f": 3, "w": 3, "e": 3}, "last": true, "tex": ["fences", Rect2(0, 0, 16, 16)]},
]
const ITEM_TEX := {
	"f": ["biom", Rect2(32, 32, 16, 16)],      # apple = food
	"w": ["milk", Rect2(0, 0, 16, 16)],        # milk jar = water
	"e": ["furniture", Rect2(64, 16, 16, 16)], # lamp = energy cell
}

enum Phase { TUTORIAL, GATHER, BUNKER, EVENT, FIX, OVER }
signal choice_made(idx: int)
signal period_ended

var phase := Phase.TUTORIAL
var res := {"f": 5, "w": 5, "e": 4, "i": 3}   # starting resources
var max_i := 3
var period := 0
var timer_left := 0.0
var busy := false              # a repair dialogue is open
var outcome := ""              # "end", "win" or "dead"
var flash := 0.0
var done := {}                 # component id -> true
var stations := {}             # component id -> Sprite2D
var items: Array = []          # [{node, key}]
var textbox: CanvasLayer
var world: Node2D
var player: Sprite2D
var pos := Vector2(160, 170)   # player's feet position
var dir := 0                   # 0 down, 1 up, 2 left, 3 right
var walk_t := 0.0
var can_walk := false
var hud: Label
var prompt: Label
var end_btn: Button
var event_panel: PanelContainer
var event_label: Label
var btn_a: Button
var btn_b: Button

func _ready() -> void:
	randomize()
	_build_world()
	_build_ui()
	textbox = TextBoxScript.new()
	add_child(textbox)
	_run()

# ---------------------------------------------------------------- game flow
func _run() -> void:
	await _say(TUTORIAL_LINES)
	await _gather()
	await _say([BUNKER_TEXT])
	while true:
		period += 1
		phase = Phase.EVENT
		var ev: Dictionary = EVENTS.pick_random()
		var pick: Dictionary = await _ask(ev)
		_apply(pick["fx"])
		if pick.get("lose", false) or _dead():
			break
		phase = Phase.FIX
		outcome = ""
		can_walk = true
		end_btn.show()
		await period_ended
		end_btn.hide()
		can_walk = false
		if outcome == "win":
			await _say([WIN_TEXT])
			_to_menu()
			return
		if outcome == "dead":
			break
		res["f"] -= 1                                   # ending a period costs 1 food
		if period % PASSIVE_EVERY == 0:
			for c in COMPONENTS:
				if done.has(c["id"]) and c.has("passive"):
					_apply(c["passive"])
		if _dead():
			break
	phase = Phase.OVER
	await _say([GAME_OVER_TEXT])
	_to_menu()

func _gather() -> void:
	phase = Phase.GATHER
	pos = Vector2(160, 170)
	_spawn_items()
	can_walk = true
	timer_left = GATHER_TIME
	while timer_left > 0.0 and not (pos.y < DOOR_Y and absf(pos.x - 160.0) < 16.0):   # entering the gate early also ends it
		await get_tree().process_frame
		timer_left -= get_process_delta_time()
		for it in items.duplicate():
			if pos.distance_to(it["node"].position) < 10.0:
				res[it["key"]] += 1
				it["node"].queue_free()
				items.erase(it)
	for it in items:
		it["node"].queue_free()
	items.clear()
	can_walk = false
	phase = Phase.BUNKER
	pos = Vector2(160, 58)                                # inside the bunker, below the door

func _ask(ev: Dictionary) -> Dictionary:
	event_label.text = ev["desc"] if ev["desc"] != "" else "[EVENT TEXT]"   # event story placeholder
	btn_a.text = ev["a"]["label"]
	btn_b.text = ev["b"]["label"]
	event_panel.show()
	event_panel.reset_size()
	await get_tree().process_frame
	event_panel.position = (get_viewport().get_visible_rect().size - event_panel.size) / 2.0
	btn_a.grab_focus()
	var idx: int = await choice_made
	event_panel.hide()
	return ev["a"] if idx == 0 else ev["b"]

func _say(lines: Array) -> void:
	textbox.show_lines(lines)
	await textbox.finished

func _repair(c: Dictionary) -> void:
	if done.has(c["id"]):
		return
	if c.get("last", false):
		for o in COMPONENTS:
			if not o.get("last", false) and not done.has(o["id"]):
				_warn("Repair every other component first")
				return
	for k in c["cost"]:
		if res[k] < c["cost"][k]:
			_warn("Not enough resources")
			return
	busy = true
	for k in c["cost"]:
		res[k] -= c["cost"][k]
	done[c["id"]] = true
	stations[c["id"]].modulate = Color.WHITE
	if c.get("perm", false):
		max_i += 1
		res["i"] += 1
	if _dead():
		outcome = "dead"
	await _say([REPAIR_TEXT[c["id"]]])                    # repair dialogue
	if outcome == "" and c.get("last", false):
		outcome = "win"
	busy = false
	if outcome != "":
		period_ended.emit()

func _apply(fx: Dictionary) -> void:
	for k in fx:
		res[k] += fx[k]

func _dead() -> bool:
	return res["f"] <= 0 or res["w"] <= 0 or res["i"] <= 0

func _to_menu() -> void:
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")

# ---------------------------------------------------------------- per-frame
func _unhandled_input(event: InputEvent) -> void:
	if phase == Phase.FIX and not busy and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
		var c := _nearest()
		if not c.is_empty():
			_repair(c)

func _process(delta: float) -> void:
	if can_walk and not busy:
		var v := Vector2(
			int(Input.is_physical_key_pressed(KEY_D)) - int(Input.is_physical_key_pressed(KEY_A)),
			int(Input.is_physical_key_pressed(KEY_S)) - int(Input.is_physical_key_pressed(KEY_W)))
		if v != Vector2.ZERO:
			var step := v.normalized() * SPEED * delta
			var nx := Vector2(clampf(pos.x + step.x, 8.0, 312.0), pos.y)
			if not _blocked(nx):
				pos = nx
			var ny := Vector2(pos.x, clampf(pos.y + step.y, 12.0, 236.0))
			if not _blocked(ny):
				pos = ny
			dir = (3 if v.x > 0 else 2) if absf(v.x) > absf(v.y) else (0 if v.y > 0 else 1)
			walk_t += delta * 8.0
		else:
			walk_t = 0.0
	var f := int(walk_t) % 4
	player.region_rect = Rect2(f * 48 + 16, dir * 48 + 16, 16, 16)
	player.position = pos + Vector2(0, -4)
	player.visible = phase != Phase.OVER
	_update_hud(delta)

func _blocked(p: Vector2) -> bool:
	for w in WALLS:
		if w.has_point(p):
			return true
	return false

func _nearest() -> Dictionary:
	for c in COMPONENTS:
		if pos.distance_to(c["pos"] + Vector2(8, 8)) < REACH:
			return c
	return {}

func _update_hud(delta: float) -> void:
	hud.text = "FOOD %d   WATER %d   ENERGY %d   SUIT %d/%d   PERIOD %d" % [res["f"], res["w"], res["e"], res["i"], max_i, period]
	if phase == Phase.GATHER:
		hud.text += "   TIME %d" % ceili(maxf(timer_left, 0.0))
	if flash > 0.0:
		flash -= delta
		return
	prompt.text = ""
	if phase == Phase.FIX and not busy:
		var c := _nearest()
		if not c.is_empty():
			var cost := ""
			for k in c["cost"]:
				cost += " %d%s" % [c["cost"][k], str(k).to_upper()]
			prompt.text = c["name"] + (" (repaired)" if done.has(c["id"]) else "  -  press E to repair:" + cost)

func _warn(msg: String) -> void:
	prompt.text = msg
	flash = 1.5

# ---------------------------------------------------------------- building nodes
func _atlas(sheet: String, region: Rect2) -> AtlasTexture:
	var t := AtlasTexture.new()
	t.atlas = load("res://assets/%s.png" % sheet)
	t.region = region
	return t

func _spawn_items() -> void:
	for i in 12:
		var key: String = ["f", "w", "e"][i % 3]
		var s := Sprite2D.new()
		s.texture = _atlas(ITEM_TEX[key][0], ITEM_TEX[key][1])
		s.position = Vector2(randf_range(14, 306), randf_range(116, 226))
		world.add_child(s)
		items.append({"node": s, "key": key})

func _build_world() -> void:
	world = Node2D.new()
	world.scale = Vector2(3, 3)
	add_child(world)
	var map := Sprite2D.new()
	map.texture = load("res://assets/map.png")
	map.centered = false
	world.add_child(map)
	for c in COMPONENTS:
		var s := Sprite2D.new()
		s.texture = _atlas(c["tex"][0], c["tex"][1])
		s.position = c["pos"] + Vector2(8, 8)
		s.modulate = Color(0.55, 0.55, 0.55)             # dim until repaired
		world.add_child(s)
		var l := Label.new()
		l.text = c["name"]
		l.add_theme_font_size_override("font_size", 18)
		l.add_theme_constant_override("outline_size", 6)
		l.add_theme_color_override("font_outline_color", Color.BLACK)
		l.scale = Vector2(1.0 / 3.0, 1.0 / 3.0)
		l.position = Vector2(-30, -22)
		l.size = Vector2(180, 30)                         # 3x the old 60x10, since the label is scaled down 3x
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		s.add_child(l)
		stations[c["id"]] = s
	player = Sprite2D.new()
	player.texture = load("res://assets/character.png")
	player.region_enabled = true
	player.region_rect = Rect2(16, 16, 16, 16)
	world.add_child(player)

func _label(parent: Node, size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	parent.add_child(l)
	return l

func _button(parent: Node, size: int) -> Button:
	var b := Button.new()
	b.add_theme_font_size_override("font_size", size)
	parent.add_child(b)
	return b

func _build_ui() -> void:
	var ui := CanvasLayer.new()
	add_child(ui)
	hud = _label(ui, 22)
	hud.position = Vector2(12, 6)
	prompt = _label(ui, 24)
	prompt.position = Vector2(12, 40)
	end_btn = _button(ui, 24)
	end_btn.text = "END PERIOD (-1 FOOD)"
	end_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	end_btn.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	end_btn.offset_right = -12
	end_btn.offset_top = 76
	end_btn.pressed.connect(_on_end_pressed)
	end_btn.hide()
	
	event_panel = PanelContainer.new()
	ui.add_child(event_panel)
	var box := VBoxContainer.new()
	
	box.add_theme_constant_override("separation", 12)
	event_panel.add_child(box)
	event_label = _label(box, 28)
	event_label.custom_minimum_size = Vector2(640, 0)
	event_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	btn_a = _button(box, 24)
	btn_b = _button(box, 24)
	btn_a.pressed.connect(func(): choice_made.emit(0))
	btn_b.pressed.connect(func(): choice_made.emit(1))
	event_panel.hide()

func _on_end_pressed() -> void:
	if phase == Phase.FIX and not busy:
		outcome = "end"
		period_ended.emit()
