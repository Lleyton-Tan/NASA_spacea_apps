extends CanvasLayer
## Responsive dialogue box.
##   textbox.show_lines(["one", {"name": "Astronaut", "text": "two"}])
##   await textbox.finished
## Enter / Space / left-click: first press completes the typing, second press shows the next line.

signal finished

const CHAR_DELAY := 0.02

var queue: Array = []
var typing := false
var tween: Tween
var panel: PanelContainer
var name_label: Label
var text_label: Label
var hint_label: Label

func _init() -> void:
	layer = 10                                  # above HUD and event panel

func _ready() -> void:
	panel = PanelContainer.new()
	panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	panel.offset_left = 24
	panel.offset_right = -24
	panel.offset_top = -216
	panel.offset_bottom = -24
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(margin)
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(box)
	name_label = Label.new()
	name_label.add_theme_font_size_override("font_size", 28)
	box.add_child(name_label)
	text_label = Label.new()
	text_label.add_theme_font_size_override("font_size", 28)
	text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(text_label)
	hint_label = Label.new()
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hint_label.add_theme_font_size_override("font_size", 20)
	box.add_child(hint_label)
	panel.hide()

func is_open() -> bool:
	return panel.visible

func show_lines(lines: Array) -> void:
	queue = lines.duplicate()
	_next()

func _next() -> void:
	if queue.is_empty():
		panel.hide()
		typing = false
		finished.emit()
		return
	var entry = queue.pop_front()
	var speaker := ""
	var text := ""
	if entry is Dictionary:
		speaker = str(entry.get("name", ""))
		text = str(entry.get("text", ""))
	else:
		text = str(entry)
	name_label.text = speaker
	name_label.visible = speaker != ""
	text_label.text = text
	text_label.visible_ratio = 0.0
	hint_label.text = ""
	panel.show()
	typing = true
	if tween:
		tween.kill()
	if text.is_empty():                         # blank placeholder: no typing delay
		_finish_typing()
		return
	tween = create_tween()
	tween.tween_property(text_label, "visible_ratio", 1.0, text.length() * CHAR_DELAY)
	tween.tween_callback(_finish_typing)

func _finish_typing() -> void:
	if tween:
		tween.kill()
	text_label.visible_ratio = 1.0
	hint_label.text = "[ENTER]"
	typing = false

func _input(event: InputEvent) -> void:
	if not panel.visible:
		return
	var pressed: bool = event.is_action_pressed("ui_accept") \
		or (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT)
	if not pressed:
		return
	get_viewport().set_input_as_handled()       # key/click must not leak into buttons or the player
	if typing:
		_finish_typing()
	else:
		_next()
