extends Control
## Main menu: Start Game / Quit Game.

func _ready() -> void:
	var bg := TextureRect.new()
	bg.texture = load("res://assets/space.png")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.grow_horizontal = Control.GROW_DIRECTION_BOTH
	box.grow_vertical = Control.GROW_DIRECTION_BOTH
	box.add_theme_constant_override("separation", 24)
	add_child(box)

	var title := Label.new()
	title.text = "MARS BASE SURVIVAL"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 56)
	box.add_child(title)

	var start := _button("START", 36)
	start.pressed.connect(_on_start)
	box.add_child(start)
	start.grab_focus()

	if not OS.has_feature("web"):             # browsers can't quit a page
		var quit := _button("QUIT GAME", 36)
		quit.pressed.connect(func(): get_tree().quit())
		box.add_child(quit)

func _button(text: String, size: int) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(320, 64)
	b.add_theme_font_size_override("font_size", size)
	return b

func _on_start() -> void:
	get_tree().change_scene_to_file("res://scenes/game.tscn")
