extends Node2D
## Mars base survival controller. Attach to the GameLevel root (already done in game_level.tscn).

# ===================== TEXT PLACEHOLDERS: fill these in =====================
# TUTORIAL DIALOGUE: one string per box. Teach WASD gathering, the 15s timer, events, repairs, End Period, win/lose.
const TUTORIAL_LINES := ["", "", "", "", ""]
# DIALOGUE: shown when the 15s gathering ends and the astronaut returns to the bunker.
const BUNKER_TEXT := ""
# DIALOGUE: shown after each repair (one per component id).
const REPAIR_TEXT := {"solar": "", "shield": "", "food": "", "humid": "", "antenna": ""}
# DIALOGUE: game over message (then back to main menu) and win / congratulation message.
const GAME_OVER_TEXT := ""
const WIN_TEXT := ""
# EVENT STORY TEXT: fill each event's "desc" below.
# ============================================================================

const ART := "res://Art/Sprout Lands - Sprites - Basic pack/Sprout Lands - Sprites - Basic pack/"
const GATHER_TIME := 15.0
const PASSIVE_EVERY := 2          # passive components produce every N periods
const REACH := 30.0               # pickup / interact distance (level units)
const DOOR := Vector2(480, 100)   # bunker door (level coordinates)
const AVOID := Rect2(350, 140, 100, 140)   # cliff tiles, keep items off them

# fx keys: f=food w=water e=energy i=suit integrity. lose=true -> instant game over.
const EVENTS := [
	{"desc": "", "a": {"label": "Consume 3 water, create 2 food", "fx": {"w": -3, "f": 2}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "", "a": {"label": "Consume 2 water, create 2 energy", "fx": {"w": -2, "e": 2}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "", "a": {"label": "Consume 2 water, +1 suit integrity", "fx": {"w": -2, "i": 1}}, "b": {"label": "Don't use the water", "fx": {}}},
	{"desc": "", "a": {"label": "Consume 2 food, create 2 water", "fx": {"f": -2, "w": 2}}, "b": {"label": "Don't use food", "fx": {}}},
	{"desc": "", "a": {"label": "Consume 2 food, create 2 energy", "fx": {"f": -2, "e": 2}}, "b": {"label": "Don't use food", "fx": {}}},
	{"desc": "", "a": {"label": "Consume 1 food, +1 suit integrity", "fx": {"f": -1, "i": 1}}, "b": {"label": "Don't use the food", "fx": {}}},
	{"desc": "", "a": {"label": "Spend 2 energy, create 2 water", "fx": {"e": -2, "w": 2}}, "b": {"label": "Don't spend energy", "fx": {}}},
	{"desc": "", "a": {"label": "Spend 2 energy, create 2 food", "fx": {"e": -2, "f": 2}}, "b": {"label": "Don't spend energy", "fx": {}}},
	{"desc": "", "a": {"label": "Spend 1 integrity, create 2 food", "fx": {"i": -1, "f": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	{"desc": "", "a": {"label": "Spend 1 integrity, create 2 water", "fx": {"i": -1, "w": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	{"desc": "", "a": {"label": "Spend 1 integrity, create 2 energy", "fx": {"i": -1, "e": 2}}, "b": {"label": "Don't spend integrity", "fx": {}}},
	# solar flare
	{"desc": "", "a": {"label": "Hide under your resources (-2 food, -2 water)", "fx": {"f": -2, "w": -2}}, "b": {"label": "Power the radiation shield (-1 energy, -1 integrity)", "fx": {"e": -1, "i": -1}}},
	# dust storm
	{"desc": "", "a": {"label": "Exit to strengthen the bunker (-1 water, -1 food)", "fx": {"w": -1, "f": -1}}, "b": {"label": "Stay inside (-2 energy cells)", "fx": {"e": -2}}},
	# radiation spike
	{"desc": "", "a": {"label": "Sleep in your suit (-1 integrity)", "fx": {"i": -1}}, "b": {"label": "Don't", "fx": {}, "lose": true}},
	# cold night
	{"desc": "", "a": {"label": "Turn on the heater (-1 energy)", "fx": {"e": -1}}, "b": {"label": "Don't (-1 water)", "fx": {"w": -1}}},
]

# Stations: pos is in level coordinates, move them freely. tex = [file, Rect2 region].
const COMPONENTS := [
	{"id": "solar", "name": "Solar panels", "pos": Vector2(120, 140), "cost": {"f": 1, "w": 1, "e": 1, "i": 1}, "passive": {"e": 1},
		"tex": ["Objects/Basic Furniture.png", Rect2(32, 0, 16, 16)]},
	{"id": "shield", "name": "Radiation shielding", "pos": Vector2(240, 140), "cost": {"f": 1, "w": 1, "e": 2}, "perm": true,
		"tex": ["Objects/Chest.png", Rect2(16, 16, 16, 16)]},
	{"id": "food", "name": "Food generator", "pos": Vector2(720, 140), "cost": {"f": 2, "w": 1, "e": 2}, "passive": {"f": 1},
		"tex": ["Objects/Basic Furniture.png", Rect2(48, 32, 16, 16)]},
	{"id": "humid", "name": "Humidifier", "pos": Vector2(840, 140), "cost": {"f": 2, "w": 2, "e": 2}, "passive": {"w": 1},
		"tex": ["Objects/Basic Furniture.png", Rect2(16, 0, 16, 16)]},
	{"id": "antenna", "name": "Antenna (final)", "pos": Vector2(480, 170), "cost": {"f": 3, "w": 3, "e": 3}, "last": true,
		"tex": ["Tilesets/Fences.png", Rect2(0, 0, 16, 16)]},
]
const ITEM_TEX := {
	"f": ["Objects/Basic Grass Biom things 1.png", Rect2(32, 32, 16, 16)],   # apple
	"w": ["Objects/Simple Milk and grass item.png", Rect2(0, 0, 16, 16)],     # milk jar
	"e": ["Objects/Basic Furniture.png", Rect2(64, 16, 16, 16)],              # lamp = energy cell
}

enum Phase { TUTORIAL, GATHER, EVENT, FIX, OVER }
signal choice_made(idx: int)
signal period_ended

@onready var player: CharacterBody2D = $Player
var textbox
var font: Font = load("res://Art/ByteBounce.ttf")
var hud: Label
var prompt: Label
var end_btn: Button
var event_panel: PanelContainer
var event_label: Label
var btn_a: Button
var btn_b: Button

var res := {"f": 5, "w": 5, "e": 4, "i": 3}   # starting resources: tweak here
var max_i := 3
var period := 0
var phase := Phase.TUTORIAL
var timer_left := 0.0
var busy := false           # true while a repair dialogue is open
var outcome := ""           # "end", "win" or "dead"
var flash := 0.0            # seconds a warning message stays on screen
var done := {}
var stations := {}          # id -> Sprite2D
var items: Array = []       # [{node, key}]
var shape_offset := Vector2.ZERO

func _ready() -> void:
	randomize()
	_tint_ground()
	_build_world()
	_build_ui()
	textbox = preload("res://Text/text_box.tscn").instantiate()
	add_child(textbox)
	shape_offset = to_local($Player/CollisionShape2D.global_position) - player.position
	var cam := Camera2D.new()
	cam.limit_left = 0; cam.limit_top = 0; cam.limit_right = 1440; cam.limit_bottom = 792
	cam.position_smoothing_enabled = true
	player.add_child(cam)
	_run()

# ---------------------------------------------------------------- flow
func _run() -> void:
	_set_walk(false)
	await _say(TUTORIAL_LINES)
	await _gather()
	await _say([BUNKER_TEXT])
	while true:
		period += 1
		var ev: Dictionary = EVENTS.pick_random()
		phase = Phase.EVENT
		var pick: Dictionary = await _ask(ev)
		_apply(pick["fx"])
		if pick.get("lose", false) or _dead():
			break
		phase = Phase.FIX
		outcome = ""
		_set_walk(true)
		end_btn.show()
		await period_ended
		end_btn.hide()
		_set_walk(false)
		if outcome == "win":
			await _say([WIN_TEXT])
			_to_menu()
			return
		if outcome == "dead":
			break
		res["f"] -= 1                                   # ending a period costs 1 food
		if period % PASSIVE_EVERY == 0:
			for c in COMPONENTS:
				if done.has(c["id"]) and c.has("passive"):
					_apply(c["passive"])
		if _dead():
			break
	phase = Phase.OVER
	await _say([GAME_OVER_TEXT])
	_to_menu()

func _gather() -> void:
	phase = Phase.GATHER
	_place_player(Vector2(480, 220))
	_spawn_items()
	_set_walk(true)
	timer_left = GATHER_TIME
	while timer_left > 0.0 and _pp().distance_to(DOOR) > 22.0:   # reaching the door early also ends it
		await get_tree().process_frame
		timer_left -= get_process_delta_time()
		for it in items.duplicate():
			if _pp().distance_to(it["node"].position) < 16.0:
				res[it["key"]] += 1
				it["node"].queue_free()
				items.erase(it)
	for it in items:
		it["node"].queue_free()
	items.clear()
	_set_walk(false)
	_place_player(DOOR + Vector2(0, 30))

func _ask(ev: Dictionary) -> Dictionary:
	event_label.text = ev["desc"] if ev["desc"] != "" else "[EVENT TEXT]"
	btn_a.text = ev["a"]["label"]
	btn_b.text = ev["b"]["label"]
	event_panel.show()
	btn_a.grab_focus()
	var idx: int = await choice_made
	event_panel.hide()
	return ev["a"] if idx == 0 else ev["b"]

func _say(lines: Array) -> void:
	textbox.show_lines(lines)
	await textbox.finished

func _repair(c: Dictionary) -> void:
	if done.has(c["id"]):
		return
	if c.get("last", false):
		for o in COMPONENTS:
			if not o.get("last", false) and not done.has(o["id"]):
				_warn("Repair every other component first")
				return
	for k in c["cost"]:
		if res[k] < c["cost"][k]:
			_warn("Not enough resources")
			return
	busy = true
	for k in c["cost"]:
		res[k] -= c["cost"][k]
	done[c["id"]] = true
	stations[c["id"]].modulate = Color.WHITE
	if c.get("perm", false):
		max_i += 1
		res["i"] += 1
	if _dead():
		outcome = "dead"
	await _say([REPAIR_TEXT[c["id"]]])           # repair dialogue
	if outcome == "" and c.get("last", false):
		outcome = "win"
	busy = false
	if outcome != "":
		period_ended.emit()

func _apply(fx: Dictionary) -> void:
	for k in fx:
		res[k] += fx[k]

func _dead() -> bool:
	return res["f"] <= 0 or res["w"] <= 0 or res["i"] <= 0

func _to_menu() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")

# ---------------------------------------------------------------- input / update
func _unhandled_input(event: InputEvent) -> void:
	if phase == Phase.FIX and not busy and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
		var c := _nearest()
		if not c.is_empty():
			_repair(c)

func _process(d: float) -> void:
	hud.text = "FOOD %d   WATER %d   ENERGY %d   SUIT %d/%d   PERIOD %d" % [res["f"], res["w"], res["e"], res["i"], max_i, period]
	if phase == Phase.GATHER:
		hud.text += "   TIME %d" % ceili(timer_left)
	if flash > 0.0:
		flash -= d
		return
	prompt.text = ""
	if phase == Phase.FIX and not busy:
		var c := _nearest()
		if not c.is_empty():
			var cost := ""
			for k in c["cost"]:
				cost += " %d%s" % [c["cost"][k], k.to_upper()]
			prompt.text = c["name"] + (" (repaired)" if done.has(c["id"]) else "  -  press E to repair:" + cost)

func _warn(msg: String) -> void:
	prompt.text = msg
	flash = 1.5

func _nearest() -> Dictionary:
	for c in COMPONENTS:
		if _pp().distance_to(c["pos"]) < REACH:
			return c
	return {}

# ---------------------------------------------------------------- helpers
func _pp() -> Vector2:                            # player's collision centre in level coords
	return player.position + shape_offset

func _place_player(p: Vector2) -> void:
	player.position = p - shape_offset
	player.velocity = Vector2.ZERO

func _set_walk(on: bool) -> void:
	player.set_physics_process(on)
	player.velocity = Vector2.ZERO

func _sprite(file: String, region: Rect2, pos: Vector2) -> Sprite2D:
	var t := AtlasTexture.new()
	t.atlas = load(ART + file)
	t.region = region
	var s := Sprite2D.new()
	s.texture = t
	s.position = pos
	add_child(s)
	return s

func _spawn_items() -> void:
	for i in 12:
		var key: String = ["f", "w", "e"][i % 3]
		var p := Vector2.ZERO
		while true:
			p = Vector2(randf_range(40, 920), randf_range(230, 500))
			if not AVOID.has_point(p):
				break
		var s := _sprite(ITEM_TEX[key][0], ITEM_TEX[key][1], p)
		items.append({"node": s, "key": key})

func _build_world() -> void:
	var b := _sprite("Tilesets/Wooden House.png", Rect2(13, 21, 25, 47), DOOR + Vector2(0, -23))   # bunker
	b.z_index = -1
	for c in COMPONENTS:
		var s := _sprite(c["tex"][0], c["tex"][1], c["pos"])
		s.modulate = Color(0.55, 0.55, 0.55)     # dim until repaired
		var l := Label.new()
		l.text = c["name"]
		l.add_theme_font_override("font", font)
		l.add_theme_font_size_override("font_size", 14)
		l.position = Vector2(-40, -26)
		s.add_child(l)
		stations[c["id"]] = s

func _tint_ground() -> void:                      # green grass -> Mars red via hue shift
	var sh := Shader.new()
	sh.code = """
shader_type canvas_item;
uniform float shift = -0.17;
vec3 to_hsv(vec3 c){vec4 K=vec4(0.,-1./3.,2./3.,-1.);vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));float d=q.x-min(q.w,q.y);float e=1e-10;return vec3(abs(q.z+(q.w-q.y)/(6.*d+e)),d/(q.x+e),q.x);}
vec3 to_rgb(vec3 c){vec4 K=vec4(1.,2./3.,1./3.,3.);vec3 p=abs(fract(c.xxx+K.xyz)*6.-K.www);return c.z*mix(K.xxx,clamp(p-K.xxx,0.,1.),c.y);}
void fragment(){vec4 t=texture(TEXTURE,UV);vec3 h=to_hsv(t.rgb);h.x=fract(h.x+shift);COLOR=vec4(to_rgb(h),t.a);}
"""
	var m := ShaderMaterial.new()
	m.shader = sh
	$TileMap.material = m

func _label(parent: Node, size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_constant_override("outline_size", 8)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	parent.add_child(l)
	return l

func _button(parent: Node, size: int) -> Button:
	var b := Button.new()
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", size)
	parent.add_child(b)
	return b

func _build_ui() -> void:
	var ui := CanvasLayer.new()
	add_child(ui)
	hud = _label(ui, 34)
	hud.position = Vector2(16, 8)
	prompt = _label(ui, 34)
	prompt.position = Vector2(16, 56)
	end_btn = _button(ui, 34)
	end_btn.text = "END PERIOD (-1 FOOD)"
	end_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	end_btn.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	end_btn.offset_right = -16
	end_btn.offset_top = 90
	end_btn.pressed.connect(func():
		if phase == Phase.FIX and not busy:
			outcome = "end"
			period_ended.emit())
	end_btn.hide()
	event_panel = PanelContainer.new()
	ui.add_child(event_panel)
	event_panel.set_anchors_preset(Control.PRESET_CENTER)
	event_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	event_panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	event_panel.add_child(box)
	event_label = _label(box, 40)
	event_label.custom_minimum_size = Vector2(900, 0)
	event_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	btn_a = _button(box, 36)
	btn_b = _button(box, 36)
	btn_a.pressed.connect(func(): choice_made.emit(0))
	btn_b.pressed.connect(func(): choice_made.emit(1))
	event_panel.hide()
