extends CanvasLayer
## Responsive dialogue box. Usage from any script:
##   textbox.show_lines(["line one", {"name": "Astronaut", "text": "line two"}])
##   await textbox.finished
## Enter / Space / left-click: 1st press finishes the typing, 2nd press goes to the next line.

signal finished

const CHAR_READ_RATE := 0.02

@onready var textbox_container = $TextboxContainer
@onready var tb_name = $TextboxContainer/MarginContainer/VBoxContainer/Name
@onready var tb_text = $TextboxContainer/MarginContainer/VBoxContainer/HBoxContainer/Text
@onready var tb_end = $TextboxContainer/MarginContainer/VBoxContainer/End

var queue: Array = []
var typing := false
var tween: Tween

func _ready() -> void:
	layer = 10                                  # always draw above HUD / event panel
	process_mode = Node.PROCESS_MODE_ALWAYS
	hide_textbox()

func show_lines(lines: Array) -> void:
	queue = lines.duplicate()
	_next()

func _next() -> void:
	if queue.is_empty():
		hide_textbox()
		finished.emit()
		return
	var entry = queue.pop_front()
	var speaker := ""
	var text := ""
	if entry is Dictionary:
		speaker = entry.get("name", "")
		text = entry.get("text", "")
	else:
		text = str(entry)
	tb_name.text = speaker
	tb_text.text = text
	tb_text.visible_ratio = 0.0
	tb_end.text = ""
	textbox_container.show()
	typing = true
	if tween:
		tween.kill()
	if text.is_empty():                         # blank placeholder line: no typing delay
		_finish_typing()
		return
	tween = create_tween()
	tween.tween_property(tb_text, "visible_ratio", 1.0, text.length() * CHAR_READ_RATE)
	tween.tween_callback(_finish_typing)

func _finish_typing() -> void:
	if tween:
		tween.kill()
	tb_text.visible_ratio = 1.0
	tb_end.text = "[ENTER]"
	typing = false

func _input(event: InputEvent) -> void:
	if not textbox_container.visible:
		return
	var pressed: bool = event.is_action_pressed("ui_accept") \
		or (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT)
	if not pressed:
		return
	get_viewport().set_input_as_handled()       # stops the key/click leaking into buttons or the player
	if typing:
		_finish_typing()
	else:
		_next()

func hide_textbox() -> void:
	typing = false
	tb_name.text = ""
	tb_text.text = ""
	tb_end.text = ""
	textbox_container.hide()
